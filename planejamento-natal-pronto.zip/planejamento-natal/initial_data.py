SECTORS = {
    'Jardim': 'Jardim', 'area jardim': 'Área jardim',
    'Hall de Entrada': 'Hall de entrada',
    'Hall do auditorio/Bloco A': 'Hall do auditório / Bloco A',
    'Refeitorio': 'Refeitório', 'biblioteca': 'Biblioteca',
    'area externa': 'Área externa', 'porta sala de aula': 'Portas das salas de aula',
}
STATUSES = {'pendente': 'Pendente', 'andamento': 'Em andamento', 'concluida': 'Concluída'}
INITIAL_IDEAS = [
    ('Jardim', 'Pisca Pisca'), ('Jardim', 'Boneco de neve'),
    ('Hall de Entrada', 'Papai Noel Descendo (só perninhas)'),
    ('Hall de Entrada', 'Refletores vermelho e verde'),
    ('Hall do auditorio/Bloco A', 'Arvore espiral'), ('Hall do auditorio/Bloco A', 'Enfeite'),
    ('Refeitorio', 'Geladeira enfeitada'), ('Refeitorio', 'Nuvem de palavras na TV (QR Code e Real Time)'),
    ('area jardim', 'Fita arvore'), ('area jardim', 'Boneco de neve'),
    ('area jardim', 'Pisca pisca tipo represa (em fita)'),
    ('biblioteca', '+ facilidade de ideias/decorações'), ('area externa', 'Enfeites pinheiro'),
    ('porta sala de aula', 'Bengalas'), ('porta sala de aula', 'Grilanda/Papai Noel'),
]
