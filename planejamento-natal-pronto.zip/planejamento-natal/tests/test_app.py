import hashlib
from pathlib import Path
import sqlite3
import tempfile
import unittest
from contextlib import closing

from app import create_app


class AppTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent.parent)
        cls.config = {'TESTING': True, 'SECRET_KEY': 'test-only-secret-key-' * 3,
                      'DATABASE': str(Path(cls.temp.name) / 'natal.db'), 'SESSION_COOKIE_SECURE': False}
        cls.app = create_app(cls.config)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def setUp(self):
        self.client = self.app.test_client()
        self.client.get('/login')

    def csrf(self, client=None):
        with (client or self.client).session_transaction() as session:
            return session['csrf_token']

    def register(self, email='pessoa@exemplo.com'):
        return self.client.post('/cadastro', data={'csrf_token': self.csrf(), 'email': email,
            'password': 'UmaSenha-Teste123', 'confirm_password': 'UmaSenha-Teste123'})

    def login(self, email='pessoa@exemplo.com', password='UmaSenha-Teste123'):
        return self.client.post('/login', data={'csrf_token': self.csrf(), 'email': email, 'password': password})

    def mutation(self, method, path, data=None):
        return self.client.open(path, method=method, json=data, headers={'X-CSRF-Token': self.csrf()})

    def test_01_authentication_and_csrf(self):
        self.assertEqual(self.client.get('/').status_code, 302)
        self.assertEqual(self.client.get('/api/ideas').status_code, 401)
        self.assertEqual(self.client.post('/cadastro', data={}).status_code, 400)
        self.assertEqual(self.register().status_code, 302)
        self.assertEqual(self.client.get('/').status_code, 200)
        self.assertEqual(self.client.post('/api/ideas', json={}).status_code, 400)
        with closing(sqlite3.connect(self.config['DATABASE'])) as conn, conn:
            value = conn.execute('SELECT password_hash FROM users').fetchone()[0]
        self.assertTrue(value.startswith('scrypt:'))
        self.assertNotIn('UmaSenha-Teste123', value)
        with self.client.session_transaction() as session:
            stolen_token = session['login_token']
        cookie = self.client.get_cookie('natal_session')
        self.assertTrue(cookie.http_only)
        self.assertEqual(self.client.post('/logout', data={'csrf_token': self.csrf()}).status_code, 302)
        self.assertEqual(self.client.get('/api/ideas').status_code, 401)
        with closing(sqlite3.connect(self.config['DATABASE'])) as conn, conn:
            self.assertIsNone(conn.execute('SELECT 1 FROM sessions WHERE token_hash = ?',
                (hashlib.sha256(stolen_token.encode()).hexdigest(),)).fetchone())
        self.assertEqual(self.login(password='SenhaErrada123').status_code, 401)
        self.assertEqual(self.login().status_code, 302)

    def test_02_shared_board_validation_and_persistence(self):
        self.assertEqual(self.login().status_code, 302)
        original = self.client.get('/api/ideas').get_json()
        self.assertEqual(len(original), 15)
        self.assertEqual(self.mutation('POST', '/api/ideas', {}).status_code, 400)
        self.assertEqual(self.mutation('POST', '/api/ideas', {'sector': [], 'idea': 'x'}).status_code, 400)
        self.assertEqual(self.mutation('POST', '/api/ideas', {'sector': 'Jardim', 'idea': '  '}).status_code, 400)
        self.assertEqual(self.mutation('POST', '/api/ideas', {'sector': 'Jardim', 'idea': 'x' * 501}).status_code, 400)
        text = '<img src=x onerror=alert(1)>'
        result = self.mutation('POST', '/api/ideas', {'sector': 'Jardim', 'idea': text})
        self.assertEqual(result.status_code, 201)
        idea_id = result.get_json()['id']
        self.assertEqual(self.mutation('PUT', f'/api/ideas/{idea_id}', {'status': []}).status_code, 400)
        self.assertEqual(self.mutation('PUT', f'/api/ideas/{idea_id}', {'status': 'concluida'}).status_code, 200)
        other = self.app.test_client(); other.get('/cadastro')
        result = other.post('/cadastro', data={'csrf_token': self.csrf(other), 'email': 'outra@equipe.com',
            'password': 'OutraSenha12345', 'confirm_password': 'OutraSenha12345'})
        self.assertEqual(result.status_code, 302)
        item = next(i for i in other.get('/api/ideas').get_json() if i['id'] == idea_id)
        self.assertEqual(item['idea'], text)
        self.assertEqual(item['status'], 'concluida')
        # A fábrica usa a mesma base persistente e não duplica a carga inicial.
        restarted = create_app(self.config).test_client()
        restarted.get('/login')
        restarted.post('/login', data={'csrf_token': self.csrf(restarted), 'email': 'pessoa@exemplo.com', 'password': 'UmaSenha-Teste123'})
        self.assertEqual(len(restarted.get('/api/ideas').get_json()), 16)
        self.assertEqual(self.mutation('DELETE', f'/api/ideas/{idea_id}').status_code, 200)
        self.assertEqual(self.mutation('DELETE', f'/api/ideas/{idea_id}').status_code, 404)
        self.assertEqual(self.client.get('/health').get_json(), {'status': 'ok'})

    def test_03_registration_rules_limits_and_reset(self):
        response = self.client.post('/cadastro', data={'csrf_token': self.csrf(), 'email': 'pessoa@exemplo.com',
            'password': 'UmaSenha-Teste123', 'confirm_password': 'UmaSenha-Teste123'})
        self.assertEqual(response.status_code, 409)
        for _ in range(8):
            self.login('ausente@exemplo.com', 'SenhaErrada123')
        self.assertEqual(self.login('ausente@exemplo.com', 'SenhaErrada123').status_code, 429)
        closed = create_app({**self.config, 'REGISTRATION_OPEN': False}).test_client()
        self.assertEqual(closed.get('/cadastro').status_code, 403)
        result = self.app.test_cli_runner().invoke(args=['reset-password', 'pessoa@exemplo.com'], input='NovaSenha123456\nNovaSenha123456\n')
        self.assertEqual(result.exit_code, 0, result.output)
        self.assertEqual(self.login(password='UmaSenha-Teste123').status_code, 401)
        self.assertEqual(self.login(password='NovaSenha123456').status_code, 302)
        backup = str(Path(self.temp.name) / 'backup.db')
        self.assertEqual(self.app.test_cli_runner().invoke(args=['backup-db', backup]).exit_code, 0)
        self.assertNotEqual(self.app.test_cli_runner().invoke(args=['backup-db', backup]).exit_code, 0)
        with closing(sqlite3.connect(backup)) as conn, conn:
            self.assertEqual(conn.execute('SELECT count(*) FROM ideas').fetchone()[0], 15)

    def test_04_empty_board_not_reseeded_and_legacy_db(self):
        empty_path = str(Path(self.temp.name) / 'empty.db')
        create_app({**self.config, 'DATABASE': empty_path})
        with closing(sqlite3.connect(empty_path)) as conn, conn:
            conn.execute('DELETE FROM ideas')
        create_app({**self.config, 'DATABASE': empty_path})
        with closing(sqlite3.connect(empty_path)) as conn, conn:
            self.assertEqual(conn.execute('SELECT count(*) FROM ideas').fetchone()[0], 0)
        legacy_path = str(Path(self.temp.name) / 'legacy.db')
        with closing(sqlite3.connect(legacy_path)) as conn, conn:
            conn.execute('CREATE TABLE ideas (id INTEGER PRIMARY KEY AUTOINCREMENT, sector TEXT, idea TEXT, status TEXT)')
            conn.execute("INSERT INTO ideas VALUES (1, 'Jardim', 'Ideia antiga', 'pendente')")
        create_app({**self.config, 'DATABASE': legacy_path})
        with closing(sqlite3.connect(legacy_path)) as conn, conn:
            self.assertEqual(conn.execute('SELECT idea FROM ideas').fetchall(), [('Ideia antiga',)])


if __name__ == '__main__':
    unittest.main()
