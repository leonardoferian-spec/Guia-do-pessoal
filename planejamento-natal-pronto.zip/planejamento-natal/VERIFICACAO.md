# Verificação da entrega

Data: 19/10/2026. Nenhuma versão foi publicada em uma hospedagem.

- Testes automatizados: **4 cenários integrados aprovados**, incluindo cadastro, autenticação, sessão revogada no logout, proteção CSRF, validação, limite de tentativas, duas contas no mesmo quadro, persistência entre inicializações, base antiga, backup e redefinição de senha.
- JavaScript: sintaxe validada com `node --check static/app.js`.
- Python: sintaxe dos módulos validada; execução com Python 3.12, Flask 3.1.3 e Werkzeug 3.1.9.
- Navegador: cadastro de uma conta descartável local, carregamento das 15 ideias originais, inclusão de ideia, alteração para concluída e busca conferidos. Layout observado em larguras de celular e desktop.
- Pacote: exclui banco de teste, conta de teste, chave de desenvolvimento, `.env`, ambiente virtual e arquivos temporários. A configuração real é gerada no servidor pelo responsável.
- Não executados neste ambiente: build Docker, Gunicorn no Linux, emissão de certificado e publicação no PythonAnywhere ou Hostinger. O Docker não está instalado neste computador. Esses passos dependem da hospedagem escolhida e do domínio.

O cadastro está aberto para qualquer e-mail, conforme solicitado. Não há confirmação de propriedade do e-mail nem envio automático de recuperação de senha. O README explica como fechar novos cadastros e redefinir uma senha pelo terminal.
