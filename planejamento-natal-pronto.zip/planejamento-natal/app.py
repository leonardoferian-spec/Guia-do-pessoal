"""Planejamento compartilhado de Natal. Python 3.11+ e SQLite persistente."""
import hashlib
import hmac
import os
from pathlib import Path
import re
import secrets
import sqlite3
import time
from datetime import timedelta
from functools import wraps
from contextlib import closing

import click
from dotenv import load_dotenv
from flask import Flask, abort, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.exceptions import HTTPException
from werkzeug.security import check_password_hash, generate_password_hash
from initial_data import INITIAL_IDEAS, SECTORS, STATUSES

BASE = Path(__file__).resolve().parent
load_dotenv(BASE / '.env', override=False)


def create_app(test_config=None):
    app = Flask(__name__)
    production = os.environ.get('APP_ENV', 'development') == 'production'
    app.config.update(
        DATABASE=os.environ.get('DATABASE_PATH', str(BASE / 'data' / 'natal.db')),
        SECRET_KEY=os.environ.get('SECRET_KEY'),
        SESSION_COOKIE_NAME='natal_session', SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE='Lax', SESSION_COOKIE_SECURE=production,
        PERMANENT_SESSION_LIFETIME=timedelta(days=7), MAX_CONTENT_LENGTH=8192,
        REGISTRATION_OPEN=os.environ.get('REGISTRATION_OPEN', 'true').lower() == 'true',
    )
    if test_config:
        app.config.update(test_config)
    if not app.config['SECRET_KEY']:
        if production:
            raise RuntimeError('Defina SECRET_KEY no ambiente ou no arquivo .env antes de iniciar em produção.')
        secret_file = BASE / 'data' / '.development-secret'
        secret_file.parent.mkdir(parents=True, exist_ok=True)
        try:
            with secret_file.open('x') as stream:
                stream.write(secrets.token_hex(32))
            secret_file.chmod(0o600)
        except FileExistsError:
            pass
        app.config['SECRET_KEY'] = secret_file.read_text().strip()
    if len(app.config['SECRET_KEY']) < 32:
        raise RuntimeError('SECRET_KEY deve ter pelo menos 32 caracteres aleatórios.')

    def db():
        if 'db' not in g:
            g.db = sqlite3.connect(app.config['DATABASE'], timeout=20)
            g.db.row_factory = sqlite3.Row
            g.db.execute('PRAGMA foreign_keys = ON')
            g.db.execute('PRAGMA busy_timeout = 20000')
        return g.db

    @app.teardown_appcontext
    def close_db(_error=None):
        connection = g.pop('db', None)
        if connection:
            connection.close()

    def init_db():
        Path(app.config['DATABASE']).resolve().parent.mkdir(parents=True, exist_ok=True)
        connection = db()
        connection.executescript('''
            CREATE TABLE IF NOT EXISTS ideas (
                id INTEGER PRIMARY KEY AUTOINCREMENT, sector TEXT NOT NULL,
                idea TEXT NOT NULL, status TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS sessions (
                token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                expires_at INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS auth_attempts (
                key TEXT PRIMARY KEY, count INTEGER NOT NULL, expires_at INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        ''')
        # A transação também protege a primeira inicialização com múltiplos workers.
        with connection:
            connection.execute('BEGIN IMMEDIATE')
            if not connection.execute("SELECT 1 FROM metadata WHERE key = 'seed-v1'").fetchone():
                if not connection.execute('SELECT 1 FROM ideas LIMIT 1').fetchone():
                    connection.executemany('INSERT INTO ideas (sector, idea, status) VALUES (?, ?, ?)',
                                           [(sector, idea, 'pendente') for sector, idea in INITIAL_IDEAS])
                connection.execute("INSERT INTO metadata VALUES ('seed-v1', 'done')")

    @app.before_request
    def security():
        session.setdefault('csrf_token', secrets.token_urlsafe(32))
        g.user = None
        token = session.get('login_token')
        if token:
            g.user = db().execute('''SELECT users.id, users.email FROM sessions JOIN users
                ON users.id = sessions.user_id WHERE token_hash = ? AND expires_at > ?''',
                (hashlib.sha256(token.encode()).hexdigest(), int(time.time()))).fetchone()
        if request.method in ('POST', 'PUT', 'PATCH', 'DELETE'):
            expected = session.get('csrf_token', '')
            supplied = request.headers.get('X-CSRF-Token') if request.path.startswith('/api/') else request.form.get('csrf_token', '')
            if not supplied or not hmac.compare_digest(expected.encode(), supplied.encode()):
                abort(400, 'Sua sessão expirou. Atualize a página e tente novamente.')

    @app.after_request
    def headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'same-origin'
        response.headers['Content-Security-Policy'] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
        )
        if not request.path.startswith('/static/'):
            response.headers['Cache-Control'] = 'no-store'
        return response

    @app.errorhandler(HTTPException)
    def http_error(error):
        if request.path.startswith('/api/'):
            return jsonify(error=error.description), error.code
        return render_template('error.html', message=error.description, code=error.code), error.code

    @app.errorhandler(500)
    def server_error(_error):
        message = 'Não foi possível concluir. Tente novamente em instantes.'
        if request.path.startswith('/api/'):
            return jsonify(error=message), 500
        return render_template('error.html', message=message, code=500), 500

    def login_required(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if not g.user:
                if request.path.startswith('/api/'):
                    abort(401, 'Entre na sua conta para acessar o planejamento.')
                return redirect(url_for('login'))
            return fn(*args, **kwargs)
        return wrapper

    def authenticate(register=False):
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        if len(email) > 254 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email):
            return 'Informe um e-mail válido.', 400
        if not 10 <= len(password) <= 128:
            return 'A senha deve ter entre 10 e 128 caracteres.', 400
        now = int(time.time())
        # Limite persistente compartilhado entre workers, sem depender de IP de proxy.
        key = hashlib.sha256(f'{email}:{now // 900}'.encode()).hexdigest()
        connection = db()
        with connection:
            connection.execute('BEGIN IMMEDIATE')
            attempt = connection.execute('SELECT count FROM auth_attempts WHERE key = ?', (key,)).fetchone()
            if attempt and attempt['count'] >= 8:
                return 'Muitas tentativas. Tente novamente em 15 minutos.', 429
            connection.execute('DELETE FROM auth_attempts WHERE expires_at < ?', (now,))
            connection.execute('''INSERT INTO auth_attempts VALUES (?, 1, ?)
                ON CONFLICT(key) DO UPDATE SET count = count + 1''', (key, now + 900))
        user = connection.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        if register:
            if not app.config['REGISTRATION_OPEN']:
                return 'O cadastro de novas contas está fechado.', 403
            if user:
                return 'Este e-mail já tem uma conta. Use a opção Entrar.', 409
            if password != request.form.get('confirm_password'):
                return 'As senhas não conferem.', 400
            password_hash = generate_password_hash(password, method='scrypt:32768:8:1')
            try:
                with connection:
                    cursor = connection.execute('INSERT INTO users (email, password_hash) VALUES (?, ?)', (email, password_hash))
                user_id = cursor.lastrowid
            except sqlite3.IntegrityError:
                return 'Este e-mail já tem uma conta.', 409
        else:
            # Hash fictício mantém o custo de verificação para e-mails inexistentes.
            valid = check_password_hash(user['password_hash'] if user else app.config['DUMMY_HASH'], password)
            if not user or not valid:
                return 'E-mail ou senha incorretos.', 401
            user_id = user['id']
        token = secrets.token_urlsafe(32)
        with connection:
            connection.execute('DELETE FROM sessions WHERE expires_at <= ?', (now,))
            connection.execute('INSERT INTO sessions VALUES (?, ?, ?)',
                               (hashlib.sha256(token.encode()).hexdigest(), user_id, now + 7 * 86400))
            connection.execute('DELETE FROM auth_attempts WHERE key = ?', (key,))
        session.clear()
        session.permanent = True
        session['login_token'] = token
        session['csrf_token'] = secrets.token_urlsafe(32)
        return None, 200

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if g.user:
            return redirect(url_for('index'))
        error, status = authenticate() if request.method == 'POST' else (None, 200)
        if request.method == 'POST' and not error:
            return redirect(url_for('index'))
        return render_template('auth.html', register=False, error=error, registration_open=app.config['REGISTRATION_OPEN']), status

    @app.route('/cadastro', methods=['GET', 'POST'])
    def register():
        if g.user:
            return redirect(url_for('index'))
        if not app.config['REGISTRATION_OPEN']:
            abort(403, 'O cadastro de novas contas está fechado.')
        error, status = authenticate(True) if request.method == 'POST' else (None, 200)
        if request.method == 'POST' and not error:
            return redirect(url_for('index'))
        return render_template('auth.html', register=True, error=error, registration_open=True), status

    @app.post('/logout')
    @login_required
    def logout():
        with db() as connection:
            connection.execute('DELETE FROM sessions WHERE token_hash = ?',
                               (hashlib.sha256(session['login_token'].encode()).hexdigest(),))
        session.clear()
        return redirect(url_for('login'))

    @app.get('/')
    @login_required
    def index():
        return render_template('index.html', sectors=SECTORS, statuses=STATUSES)

    @app.get('/health')
    def health():
        db().execute('SELECT 1 FROM ideas LIMIT 1')
        return jsonify(status='ok')

    def json_body():
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            abort(400, 'Envie um objeto JSON válido.')
        return data

    @app.get('/api/ideas')
    @login_required
    def get_ideas():
        return jsonify([dict(row) for row in db().execute('SELECT * FROM ideas ORDER BY id')])

    @app.post('/api/ideas')
    @login_required
    def add_idea():
        data = json_body()
        sector, idea = data.get('sector'), data.get('idea')
        if not isinstance(sector, str) or sector not in SECTORS:
            abort(400, 'Selecione uma área válida.')
        if not isinstance(idea, str) or not 1 <= len(idea.strip()) <= 500:
            abort(400, 'A ideia deve ter entre 1 e 500 caracteres.')
        with db() as connection:
            cursor = connection.execute("INSERT INTO ideas (sector, idea, status) VALUES (?, ?, 'pendente')", (sector, idea.strip()))
        return jsonify(id=cursor.lastrowid), 201

    @app.route('/api/ideas/<int:idea_id>', methods=['PUT', 'DELETE'])
    @login_required
    def change_idea(idea_id):
        connection = db()
        with connection:
            if request.method == 'PUT':
                status = json_body().get('status')
                if not isinstance(status, str) or status not in STATUSES:
                    abort(400, 'Status inválido.')
                cursor = connection.execute('UPDATE ideas SET status = ? WHERE id = ?', (status, idea_id))
            else:
                cursor = connection.execute('DELETE FROM ideas WHERE id = ?', (idea_id,))
            if not cursor.rowcount:
                abort(404, 'Ideia não encontrada.')
        return jsonify(success=True)

    @app.cli.command('reset-password')
    @click.argument('email')
    @click.password_option(confirmation_prompt=True)
    def reset_password(email, password):
        """Redefine senha pelo terminal e encerra as sessões dessa conta."""
        if not 10 <= len(password) <= 128:
            raise click.ClickException('A senha deve ter entre 10 e 128 caracteres.')
        connection = db()
        user = connection.execute('SELECT id FROM users WHERE email = ?', (email.strip().lower(),)).fetchone()
        if not user:
            raise click.ClickException('Conta não encontrada.')
        with connection:
            connection.execute('UPDATE users SET password_hash = ? WHERE id = ?',
                               (generate_password_hash(password, method='scrypt:32768:8:1'), user['id']))
            connection.execute('DELETE FROM sessions WHERE user_id = ?', (user['id'],))
        click.echo('Senha alterada. A pessoa deverá entrar novamente.')

    @app.cli.command('backup-db')
    @click.argument('destination', type=click.Path(path_type=Path))
    def backup_db(destination):
        """Faz backup consistente do SQLite sem sobrescrever arquivos."""
        if destination.exists():
            raise click.ClickException('O destino já existe. Escolha outro nome.')
        destination.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(destination)) as target:
            db().backup(target)
        click.echo(f'Backup salvo em {destination.resolve()}')

    with app.app_context():
        init_db()
    app.config['DUMMY_HASH'] = generate_password_hash(secrets.token_urlsafe(32), method='scrypt:32768:8:1')
    return app


if __name__ == '__main__':
    create_app().run(host='127.0.0.1', port=int(os.environ.get('PORT', 5000)), debug=False)
