# Planejamento de Natal

Projeto preparado para hospedagem, sem publicação automática. Python 3.11 ou superior, Flask e SQLite. Mantém as 8 áreas e as 15 ideias originais. Cada pessoa cria uma conta com e-mail e senha; todas as contas compartilham o mesmo quadro e podem adicionar, alterar o status e excluir ideias.

## Começar pelo caminho mais barato

Para uso leve de uma equipe, a indicação inicial é **PythonAnywhere no plano gratuito (US$ 0/mês)**. O plano oferece um site no subdomínio do usuário e 512 MiB de espaço. Há limites de recursos e expiração de 1 mês no plano gratuito: acompanhe o botão de extensão/renovação na aba Web. Não conte com domínio próprio no plano gratuito.

Preços e limites consultados em 19/10/2026:

| Serviço | Serve para este pacote? | Observação |
|---|---|---|
| PythonAnywhere gratuito | Sim | Recomendação para começar sem mensalidade; renovar o site no painel e acompanhar os limites. |
| Hostinger VPS | Sim | Preço anunciado a partir de R$ 29,99/mês na promoção; acima de R$ 10/mês. Confira prazo de contratação e renovação antes de pagar. |
| Hostinger compartilhada | Não | A Hostinger informa que seus planos compartilhados não executam Python. Precisaria de uma versão adaptada para PHP. |
| GitHub | Para guardar o código | GitHub Pages serve arquivos estáticos; não executa este servidor Python nem seu banco. O código pode ficar no GitHub e o site no PythonAnywhere. |

Fontes oficiais: [PythonAnywhere preços](https://www.pythonanywhere.com/pricing/), [limites gratuitos](https://help.pythonanywhere.com/pages/FreeAccountsFeatures/), [Hostinger Python](https://www.hostinger.com/br/support/3648030-voces-suportam-python-na-hostinger/), [Hostinger VPS](https://www.hostinger.com/br/vps/hospedagem-django), [GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages).

## Testar no seu computador

Extraia o ZIP em uma pasta. No terminal dessa pasta:

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe configurar.py
.venv\Scripts\python.exe app.py
```

Abra **http://127.0.0.1:5000** e clique em **Criar uma conta**. Não existe usuário ou senha padrão. `configurar.py` gera uma chave aleatória em `.env`; não exibe nem envia a chave. Se o arquivo já existir, ele não será sobrescrito.

Em Linux/macOS, troque `.venv\Scripts\python.exe` por `.venv/bin/python`.

O comando `python app.py` é apenas para testar localmente. A configuração de produção está nas opções a seguir.

## Colocar no PythonAnywhere gratuito

1. Crie uma conta gratuita no [PythonAnywhere](https://www.pythonanywhere.com/). Você fará o cadastro diretamente no provedor.
2. Na aba **Files**, envie `planejamento-natal-pronto.zip` para sua pasta pessoal. Abra um console **Bash**.
3. Extraia o ZIP. O pacote contém a pasta `planejamento-natal`. Se necessário, ajuste o nome do ZIP no comando:

```bash
cd ~
unzip planejamento-natal-pronto.zip
cd ~/planejamento-natal
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python configurar.py --producao
```

Use a mesma versão de Python na criação do ambiente e na aba Web. Se 3.12 não estiver disponível, use uma versão oferecida de 3.11 ou superior e ajuste o comando.

4. Abra **Web → Add a new web app → Manual configuration**. Escolha a versão de Python usada acima.
5. Em **Virtualenv**, informe `/home/SEU_USUARIO/planejamento-natal/.venv`.
6. Abra o arquivo **WSGI configuration file** indicado na aba Web. Substitua o conteúdo por este código, trocando `SEU_USUARIO` pelo seu usuário real:

```python
import sys

project_path = '/home/SEU_USUARIO/planejamento-natal'
if project_path not in sys.path:
    sys.path.insert(0, project_path)

from wsgi import application
```

7. Em **Static files**, adicione URL `/static/` e diretório `/home/SEU_USUARIO/planejamento-natal/static`.
8. Clique em **Reload**. Acesse o endereço **HTTPS** mostrado na aba Web. Se disponível, ative **Force HTTPS**. Crie sua conta e envie o endereço à equipe; cada pessoa deverá criar sua própria conta.

O `.env` será carregado automaticamente. O banco será criado em `/home/SEU_USUARIO/planejamento-natal/data/natal.db`, inclusive ao iniciar por WSGI. Não execute `app.run()` no arquivo WSGI.

Se aparecer erro 500, consulte o **Error log** na aba Web. Verifique a versão do Python, o caminho do ambiente virtual, a existência do `.env` e a permissão de escrita na pasta `data`. Cookies de produção exigem HTTPS; usar HTTP pode fazer o login voltar para a tela inicial.

Guia do provedor: [configurar Flask no PythonAnywhere](https://help.pythonanywhere.com/pages/Flask/).

## Hostinger VPS ou outro servidor com Docker

Este procedimento exige um **VPS com Docker e Docker Compose**, não hospedagem compartilhada. Transfira o projeto ao servidor. Gere a configuração:

```bash
python3 configurar.py --producao
docker compose up -d --build
docker compose logs -f site
```

O serviço fica em `127.0.0.1:8000`, acessível apenas no servidor. Configure o proxy reverso HTTPS do seu painel para esse endereço. O arquivo SQLite fica no volume Docker `natal-data`, que persiste ao recriar os contêineres. Não use `docker compose down -v`, pois isso apaga esse volume.

### HTTPS automático com domínio próprio (opcional)

Se o VPS não tiver proxy HTTPS, o pacote inclui uma configuração de Caddy. Aponte o DNS do domínio ao IP do VPS, libere as portas 80 e 443 e adicione ao `.env` uma linha com seu domínio real:

```dotenv
SITE_DOMAIN=natal.seudominio.com.br
```

Depois execute:

```bash
docker compose -f compose.yaml -f compose.https.yaml up -d --build
```

Abra `https://natal.seudominio.com.br`. A emissão do certificado exige DNS correto e portas 80/443 acessíveis; não use essas portas se já houver outro proxy no VPS. O domínio é contratado separadamente.

### Servidor Linux sem Docker

Com Python e ambiente virtual configurados, crie `.env` de produção e execute no ambiente virtual:

```bash
gunicorn -c gunicorn.conf.py wsgi:application
```

Use um serviço do sistema para manter o processo rodando e um proxy HTTPS na frente. Restrinja a porta 8000 no firewall para impedir acesso direto pela internet. Em hospedagens WSGI gerenciadas, use `wsgi:application` ou importe `application` do arquivo `wsgi.py`, conforme o painel do provedor.

## Configuração e acesso

| Variável | Uso |
|---|---|
| `APP_ENV` | `production` na hospedagem HTTPS; `development` para testar em HTTP local. |
| `SECRET_KEY` | Chave aleatória gerada por `configurar.py`; obrigatória em produção. Mantenha a mesma chave entre reinícios. |
| `DATABASE_PATH` | Caminho absoluto opcional para o banco em disco persistente; padrão `data/natal.db` ao lado de `app.py`. |
| `REGISTRATION_OPEN` | `true` permite criar conta com qualquer e-mail; `false` fecha novos cadastros. |
| `PORT` | Porta do servidor local/Gunicorn; o Compose usa 8000. |

O cadastro é aberto como solicitado: quem tem o endereço pode criar uma conta e entrar no quadro. O e-mail funciona como identificador; **não há verificação por e-mail, aprovação de cadastro ou recuperação de senha por e-mail**. Para restringir o acesso à equipe, deixe cada pessoa se cadastrar e depois altere `REGISTRATION_OPEN=false`. Reinicie/recarregue o site após mudar a configuração. No Docker: `docker compose up -d --force-recreate` (use também o arquivo HTTPS se estiver usando Caddy).

Senhas são armazenadas com hash scrypt, nunca em texto puro. Sessões têm validade de 7 dias, cookies HttpOnly e proteção CSRF. O logout revoga a sessão no banco. Há limite de tentativas de autenticação por e-mail. Todos os participantes têm o mesmo poder de alteração; não existe perfil de administrador no painel.

### Redefinir uma senha

O responsável pelo servidor pode executar, no ambiente virtual:

```bash
python -m flask --app wsgi:application reset-password pessoa@exemplo.com
```

A senha será pedida sem aparecer no terminal, com confirmação. As sessões dessa pessoa serão encerradas. Em Docker, use `docker compose exec site python -m flask --app wsgi:application reset-password pessoa@exemplo.com`.

## Backup e atualização

O arquivo do banco contém as ideias, contas e sessões. Faça backup antes de atualizar:

```bash
python -m flask --app wsgi:application backup-db backups/natal-2026-10-19.db
```

Escolha um nome diferente em cada backup. O comando não sobrescreve arquivos existentes. No Docker:

```bash
docker compose exec site python -m flask --app wsgi:application backup-db /app/data/backup.db
docker compose cp site:/app/data/backup.db ./backup.db
```

Guarde backups fora do servidor e em local privado. Para restaurar: pare o site, substitua o banco configurado por uma cópia do backup e inicie novamente. Não misture arquivos de bancos diferentes.

Ao atualizar, preserve `.env` e a pasta `data` (ou o volume Docker). Não envie `.env`, bancos, backups nem a pasta `.venv` ao GitHub. O `.gitignore` já os exclui. O banco original também é compatível: se tiver um `natal.db` antigo, faça backup e aponte `DATABASE_PATH` para ele antes de iniciar; as tabelas de contas serão criadas sem apagar as ideias existentes.

SQLite é adequado para este quadro de uma equipe pequena em uma instância. Use disco persistente; não publique este pacote em uma plataforma com disco temporário, nem execute várias instâncias com bancos separados.

## Verificação

```bash
python -m unittest discover -s tests -v
```

Os testes cobrem cadastro, login, logout, CSRF, bloqueio sem autenticação, hash de senha, limite de tentativas, quadro entre contas, criação/alteração/exclusão, validação, persistência entre reinícios, compatibilidade com o banco original, backup e redefinição de senha. Usam uma base temporária separada. `/health` é a rota de verificação do serviço e não revela ideias nem usuários.
