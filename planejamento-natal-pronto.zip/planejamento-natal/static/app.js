'use strict';
const board = document.getElementById('board');
const message = document.getElementById('message');
const csrf = document.querySelector('meta[name="csrf-token"]').content;
const sectors = Array.from(document.querySelectorAll('#newSector option')).filter(o => o.value).map(o => [o.value, o.textContent]);
const statuses = { pendente: 'Pendente', andamento: 'Em andamento', concluida: 'Concluída' };
let ideas = [];
let busy = false;
let loading = false;
function notify(text, error = false) {
  message.textContent = text; message.hidden = !text;
  message.className = `message ${error ? 'error' : 'success'}`;
}
async function api(path, options = {}) {
  const response = await fetch(path, { ...options, headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf, ...options.headers } });
  if (response.status === 401) { window.location.assign('/login'); throw new Error('Sua sessão expirou. Entre novamente.'); }
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Não foi possível salvar. Tente novamente.');
  return data;
}
function node(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}
function render() {
  document.getElementById('total').textContent = ideas.length;
  for (const [id, status] of [['pending', 'pendente'], ['progress', 'andamento'], ['done', 'concluida']]) document.getElementById(id).textContent = ideas.filter(i => i.status === status).length;
  const query = document.getElementById('search').value.toLocaleLowerCase('pt-BR').trim();
  const filter = document.getElementById('statusFilter').value;
  board.replaceChildren();
  // Dados de usuários são texto, nunca HTML executável.
  const allSectors = [...sectors];
  for (const idea of ideas) if (!allSectors.some(([key]) => key === idea.sector)) allSectors.push([idea.sector, idea.sector]);
  for (const [key, label] of allSectors) {
    const items = ideas.filter(i => i.sector === key && (!filter || i.status === filter) && `${i.idea} ${label}`.toLocaleLowerCase('pt-BR').includes(query));
    if (!items.length) continue;
    const section = node('section', 'sector'); const heading = node('div', 'sector-heading');
    heading.append(node('h3', '', label), node('span', 'count', items.length)); section.append(heading);
    for (const idea of items) {
      const card = node('article', `idea ${Object.hasOwn(statuses, idea.status) ? idea.status : 'pendente'}`);
      card.append(node('p', 'text', idea.idea)); const actions = node('div', 'actions');
      const label = node('label', 'sr-only', `Status de ${idea.idea}`); label.htmlFor = `status-${idea.id}`;
      const select = node('select', 'status-select'); select.id = label.htmlFor;
      for (const [value, text] of Object.entries(statuses)) { const option = node('option', '', text); option.value = value; select.append(option); }
      select.value = idea.status; select.disabled = busy || loading;
      select.addEventListener('change', () => mutate(`/api/ideas/${idea.id}`, 'PUT', { status: select.value }, 'Status atualizado.'));
      const remove = node('button', 'delete', 'Excluir'); remove.type = 'button'; remove.disabled = busy || loading;
      remove.setAttribute('aria-label', `Excluir ideia: ${idea.idea}`);
      remove.addEventListener('click', () => { if (window.confirm(`Excluir a ideia “${idea.idea}”?`)) mutate(`/api/ideas/${idea.id}`, 'DELETE', undefined, 'Ideia excluída.'); });
      actions.append(label, select, remove); card.append(actions); section.append(card);
    }
    board.append(section);
  }
  if (!board.childElementCount) board.append(node('p', 'empty-state', ideas.length ? 'Nenhuma ideia encontrada com esses filtros.' : 'O quadro está vazio. Adicione a primeira ideia!'));
  board.setAttribute('aria-busy', String(busy || loading));
  document.getElementById('addButton').disabled = busy || loading;
  document.getElementById('refresh').disabled = busy || loading;
}
async function loadIdeas() {
  if (loading || busy) return;
  loading = true; board.setAttribute('aria-busy', 'true'); document.getElementById('refresh').disabled = true;
  try { ideas = await api('/api/ideas'); }
  catch (error) { notify(error.message || 'Falha na conexão.', true); }
  finally { loading = false; render(); }
}
async function mutate(path, method, data, success) {
  if (busy || loading) return false;
  busy = true; render(); notify(''); let saved = false;
  try {
    await api(path, { method, ...(data ? { body: JSON.stringify(data) } : {}) }); saved = true; notify(success);
    try { ideas = await api('/api/ideas'); }
    catch { notify('A alteração foi salva, mas o quadro não atualizou. Clique em Atualizar.', true); }
  } catch (error) { notify(error.message || 'Falha na conexão. Tente novamente.', true); }
  finally { busy = false; render(); }
  return saved;
}
document.getElementById('addForm').addEventListener('submit', async event => {
  event.preventDefault(); const input = document.getElementById('newIdea'); const idea = input.value.trim();
  if (!idea) { notify('Escreva sua ideia antes de adicionar.', true); input.focus(); return; }
  const saved = await mutate('/api/ideas', 'POST', { sector: document.getElementById('newSector').value, idea }, 'Ideia adicionada.');
  if (saved && input.value.trim() === idea) { input.value = ''; input.focus(); }
});
document.getElementById('search').addEventListener('input', render);
document.getElementById('statusFilter').addEventListener('change', render);
document.getElementById('refresh').addEventListener('click', () => { notify(''); loadIdeas(); });
loadIdeas();
