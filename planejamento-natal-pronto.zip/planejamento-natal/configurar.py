"""Gera a configuração inicial sem expor a chave secreta."""
import argparse
from pathlib import Path
import secrets

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--producao', action='store_true', help='Ativa cookies exclusivos de HTTPS.')
args = parser.parse_args()
path = Path(__file__).resolve().parent / '.env'
if path.exists():
    parser.exit(1, 'O arquivo .env já existe. Edite APP_ENV manualmente para preservar a chave e os dados.\n')
content = (
    f"APP_ENV={'production' if args.producao else 'development'}\n"
    f'SECRET_KEY={secrets.token_hex(32)}\n'
    'REGISTRATION_OPEN=true\n'
    '# DATABASE_PATH=/caminho/absoluto/para/data/natal.db\n'
    'PORT=5000\n'
)
with path.open('x', encoding='utf-8') as stream:
    stream.write(content)
path.chmod(0o600)
print('Configuração .env criada. Não publique esse arquivo no GitHub.')
